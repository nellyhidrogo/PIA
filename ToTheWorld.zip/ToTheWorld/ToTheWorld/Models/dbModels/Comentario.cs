﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ToTheWorld.Models.dbModels
{
    public partial class Comentario
    {
        [Key]
        public int IdComentario { get; set; }
        public int Usuario { get; set; }
        public int Ciudad { get; set; }
        [Required]
        public string Contenido { get; set; }

        [ForeignKey(nameof(Ciudad))]
        [InverseProperty(nameof(Ciudade.Comentarios))]
        public virtual Ciudade CiudadNavigation { get; set; }
    }
}
