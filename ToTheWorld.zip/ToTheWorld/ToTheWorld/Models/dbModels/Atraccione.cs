﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ToTheWorld.Models.dbModels
{
    public partial class Atraccione
    {
        [Key]
        public int IdAtraccion { get; set; }
        [Required]
        [StringLength(50)]
        public string NombreA { get; set; }
        [Required]
        public string Direccion { get; set; }
        [Column(TypeName = "image")]
        public byte[] Imagen { get; set; }
        public string Descripción { get; set; }
        public int Ciudad { get; set; }

        [ForeignKey(nameof(Ciudad))]
        [InverseProperty(nameof(Ciudade.Atracciones))]
        public virtual Ciudade CiudadNavigation { get; set; }
    }
}
