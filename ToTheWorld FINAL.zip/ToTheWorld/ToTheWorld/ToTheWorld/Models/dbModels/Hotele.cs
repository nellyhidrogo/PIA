﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ToTheWorld.Models.dbModels
{
    public partial class Hotele
    {
        [Key]
        public int IdHotel { get; set; }
        public int Ciudad { get; set; }
        [Column("logo", TypeName = "image")]
        public byte[] Logo { get; set; }
        public string Descripción { get; set; }
        [Column("link")]
        public string Link { get; set; }

        [ForeignKey(nameof(Ciudad))]
        [InverseProperty(nameof(Ciudade.Hoteles))]
        public virtual Ciudade CiudadNavigation { get; set; }
    }
}
