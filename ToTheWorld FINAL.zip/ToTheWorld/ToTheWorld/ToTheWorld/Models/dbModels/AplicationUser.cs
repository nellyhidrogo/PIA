﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace ToTheWorld.Models.dbModels
{
    public class AplicationUser : IdentityUser<int>
    {
        public string Nombre { get; set; } 
        public string Ciudad { get; set; }
        public string Genero { get; set; }
        [InverseProperty (nameof(Usuario.IdUsuarioNavigation))]
        public virtual ICollection<Usuario> Ciudads { get; set; }
    }
}
