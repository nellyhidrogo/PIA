﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ToTheWorld.Models.dbModels
{
    public partial class Ciudade
    {
        public Ciudade()
        {
            Atracciones = new HashSet<Atraccione>();
            Comentarios = new HashSet<Comentario>();
            Hoteles = new HashSet<Hotele>();
            Restaurantes = new HashSet<Restaurante>();
            Usuarios = new HashSet<Usuario>();
        }

        [Key]
        public int IdCiudad { get; set; }
        [Required]
        [StringLength(50)]
        public string NombreC { get; set; }
        [Required]
        [StringLength(50)]
        public string Estado { get; set; }
        [Required]
        [StringLength(50)]
        public string Pais { get; set; }
        [Column(TypeName = "image")]
        public byte[] Imagen { get; set; }

        [InverseProperty(nameof(Atraccione.CiudadNavigation))]
        public virtual ICollection<Atraccione> Atracciones { get; set; }
        [InverseProperty(nameof(Comentario.CiudadNavigation))]
        public virtual ICollection<Comentario> Comentarios { get; set; }
        [InverseProperty(nameof(Hotele.CiudadNavigation))]
        public virtual ICollection<Hotele> Hoteles { get; set; }
        [InverseProperty(nameof(Restaurante.CiudadNavigation))]
        public virtual ICollection<Restaurante> Restaurantes { get; set; }
        [InverseProperty(nameof(Usuario.CiudadNavigation))]
        public virtual ICollection<Usuario> Usuarios { get; set; }
    }
}
