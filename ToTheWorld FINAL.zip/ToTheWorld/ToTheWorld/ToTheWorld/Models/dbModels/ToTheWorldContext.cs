﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ToTheWorld.Models.dbModels
{
    public partial class ToTheWorldContext : IdentityDbContext<AplicationUser, IdentityRole<int>, int>
    {
        public ToTheWorldContext()
        {
        }

        public ToTheWorldContext(DbContextOptions<ToTheWorldContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AspNetRole> AspNetRoles { get; set; }
        public virtual DbSet<AspNetRoleClaim> AspNetRoleClaims { get; set; }
        public virtual DbSet<AspNetUser> AspNetUsers { get; set; }
        public virtual DbSet<AspNetUserClaim> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserLogin> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUserRole> AspNetUserRoles { get; set; }
        public virtual DbSet<AspNetUserToken> AspNetUserTokens { get; set; }
        public virtual DbSet<Atraccione> Atracciones { get; set; }
        public virtual DbSet<Ciudade> Ciudades { get; set; }
        public virtual DbSet<Comentario> Comentarios { get; set; }
        public virtual DbSet<Hotele> Hoteles { get; set; }
        public virtual DbSet<Restaurante> Restaurantes { get; set; }
        public virtual DbSet<Usuario> Usuarios { get; set; }

       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.HasAnnotation("Relational:Collation", "Modern_Spanish_CI_AS");

            modelBuilder.Entity<AspNetRole>(entity =>
            {
                entity.HasIndex(e => e.NormalizedName, "RoleNameIndex")
                    .IsUnique()
                    .HasFilter("([NormalizedName] IS NOT NULL)");
            });

            modelBuilder.Entity<AspNetUser>(entity =>
            {
                entity.HasIndex(e => e.NormalizedUserName, "UserNameIndex")
                    .IsUnique()
                    .HasFilter("([NormalizedUserName] IS NOT NULL)");
            });

            modelBuilder.Entity<AspNetUserLogin>(entity =>
            {
                entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });
            });

            modelBuilder.Entity<AspNetUserRole>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RoleId });
            });

            modelBuilder.Entity<AspNetUserToken>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });
            });

            modelBuilder.Entity<Atraccione>(entity =>
            {
                entity.HasOne(d => d.CiudadNavigation)
                    .WithMany(p => p.Atracciones)
                    .HasForeignKey(d => d.Ciudad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Atracciones_Ciudades");
            });

            modelBuilder.Entity<Ciudade>(entity =>
            {
                entity.HasKey(e => e.IdCiudad)
                    .HasName("PK_Ciudades_1");
            });

            modelBuilder.Entity<Comentario>(entity =>
            {
                entity.HasOne(d => d.CiudadNavigation)
                    .WithMany(p => p.Comentarios)
                    .HasForeignKey(d => d.Ciudad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Comentarios_Ciudades1");
            });

            modelBuilder.Entity<Hotele>(entity =>
            {
                entity.HasOne(d => d.CiudadNavigation)
                    .WithMany(p => p.Hoteles)
                    .HasForeignKey(d => d.Ciudad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Detalle Hoteles_Ciudades");
            });

            modelBuilder.Entity<Restaurante>(entity =>
            {
                entity.HasOne(d => d.CiudadNavigation)
                    .WithMany(p => p.Restaurantes)
                    .HasForeignKey(d => d.Ciudad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Restaurantes_Ciudades");
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasOne(d => d.CiudadNavigation)
                    .WithMany(p => p.Usuarios)
                    .HasForeignKey(d => d.Ciudad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Usuarios_Ciudades1");
                entity.HasOne(d => d.IdUsuarioNavigation)
                      .WithMany(p => p.Ciudads)
                      .HasForeignKey(d => d.IdUsuario)
                      .HasConstraintName("FK_Usuario_Usuari");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
